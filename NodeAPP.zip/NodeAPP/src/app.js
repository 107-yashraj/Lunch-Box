const express = require ('express')
const path= require('path')
const app= express();
const db= require('./mongodb')
const collection= require("./models/reg")
const feedback = require("./models/feedback")
const port= process.env.PORT || 800 ;


//path
const static_path = path.join(__dirname , "../public");
app.set('view engine', 'hbs');

app.use(express.static(static_path));
app.use(express.urlencoded({extended:false}))


//routing
app.get('/', (req,res)=>{
    res.render('index')
})

app.get('/registration', (req,res)=>{
    res.render('registration')
})

app.get('/feedback', (req,res)=>{
    res.render('feedback')
})

app.get('/satisfaction', (req,res)=>{
    res.render('satisfaction')
})

app.post('/reg', async (req,res)=>{

    const data= new collection( {
        name: req.body.Fname,
        email: req.body.Email,
        pass: req.body.Pass
    });
//    const saveduser= await data.save()
    await collection.insertMany([data]);
    console.log(data);
   res.render('index',data);
})

app.post('/feedback', async (req,res)=>{

    const data= new feedback( {
        name: req.body.fname,
        email: req.body.email,
        pass: req.body.mobile,
        comment: req.body.feedback
    });  
//    const saveduser= await data.save()
    await feedback.insertMany([data]);
    console.log(data);
   res.render('index',data);
})

app.get('*', async (req,res)=>{
    const data= await collection.findOne()
    const data1= await feedback.findOne()
    res.send([data,data1]);
})

app.listen(800,()=>{
console.log("Server Is Running At http://localhost:800/")
    })